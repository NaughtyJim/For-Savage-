fx_version 'bodacious'
game 'gta5'

author 'AZTËC™#0001'
version '1.0.0'

client_scripts {
    'client/main.lua',
    'client/vehicle.lua'
}

ui_page 'client/html/index.html'

files {
    'client/html/index.html',
    'client/html/css/*.css',
    'client/html/js/*.js',
    'client/html/img/*.png',
    'client/html/img/*.svg',
    'client/html/fonts/*.ttf',
    'client/html/fonts/*.eot',
    'client/html/fonts/*.eot',
    'client/html/fonts/*.otf',
    'client/html/fonts/*.svg',
    'client/html/fonts/*.ttf',
    'client/html/fonts/*.woff',
    'client/html/fonts/*.woff2'
}