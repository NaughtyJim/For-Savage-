# Malibu Mansion Security Guards
A script that spawns security guards at the Malibu Mansion in FiveM.

Installation: 
1. Download the resource
2. Put MM-Security-Guards in your resources folder
3. Add ensure MM-Security-Guards to your server.cfg

Originally created by https://github.com/TayMcKenzieNZ, guard placements by Rob1n.

Showcase Video: https://streamable.com/v5k6sj

![1](https://user-images.githubusercontent.com/97352680/148652349-f0d189d7-ddf0-4e17-bd43-bb8f426e3128.PNG)
![2](https://user-images.githubusercontent.com/97352680/148652350-6cf989c8-9ee0-4454-8f79-f5a60978941c.PNG)
![3](https://user-images.githubusercontent.com/97352680/148652351-771d5152-3e65-41ad-865c-e13a9fe371c2.PNG)
![4](https://user-images.githubusercontent.com/97352680/148652352-6ee4bdf2-b0f7-4802-8072-8f8c3fab4ccd.PNG)
![5](https://user-images.githubusercontent.com/97352680/148652353-c0476c7a-ebbb-48c9-8f4c-74682325ef8a.PNG)
![6](https://user-images.githubusercontent.com/97352680/148652354-f506ad52-0a9a-49da-99a8-4686b7949a92.PNG)
![7](https://user-images.githubusercontent.com/97352680/148652355-a4744045-6c9a-4c16-a70b-7052292a262a.PNG)
![8](https://user-images.githubusercontent.com/97352680/148652356-6b85c14b-2fdc-4f0d-acf2-db0c61069c19.PNG)
![9](https://user-images.githubusercontent.com/97352680/148652359-c139f1e4-7a3f-4d14-8ef9-9e4ed538ec75.PNG)
