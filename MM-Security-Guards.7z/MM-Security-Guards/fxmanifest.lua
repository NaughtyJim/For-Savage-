fx_version 'cerulean'
games { 'gta5' }

author 'Rob1n'
description 'Script that spawns security guards at the Malibu Mansion. Originally created by TayMcKenzieNZ.'
version '1.0'

client_scripts {

	'peds.lua',
	'script.lua',
	
}



---                                                                     ---
---   THIS IS A FREE RESOURCE PROVIDED TO CFXE FORUMS FOR FIVEM USAGE   ---
---        DO NOT REUPLOAD OR MODIFY WITHOUT MY PERMISSION
---    YOU CAN COMMENT OUT PEDS AND TELEPORTERS IF YOU WISH TO          ---
